#!/bin/sh

echo "1. copy tcc --> /usr/local/bin"

if [ -f /usr/bin/tcc ];then
  rm /usr/bin/tcc
fi
if [ -f /usr/local/bin/tcc ];then
  rm /usr/local/bin/tcc
fi
cp tcc /usr/local/bin/

# init usr/local/lib/tcc dir
if [ -d /usr/local/lib/tcc ]; then
  rm -rf /usr/local/lib/tcc
fi
mkdir -p /usr/local/lib/tcc

echo "2. copy libtcc1.a --> /usr/local/lib/tcc/"
cp libtcc1.a  /usr/local/lib/tcc/

echo "3. copy include/* --> /usr/local/lib/tcc/include/"
cp -r ./include /usr/local/lib/tcc/

echo "4. copy sysroot/include/* --> /usr/local/include/riscv64-linux-gnu/"
if [ -d /usr/local/include/riscv64-linux-gnu ]; then
  rm -rf /usr/local/include/riscv64-linux-gnu
fi
mkdir -p /usr/local/include/riscv64-linux-gnu
cp -rf ./sysroot/include/* /usr/local/include/riscv64-linux-gnu/

echo "5. copy sysroot/lib/* --> /usr/local/lib/riscv64-linux-gnu/"
if [ -d /usr/local/lib/riscv64-linux-gnu ]; then
  rm -rf /usr/local/lib/riscv64-linux-gnu
fi
mkdir -p /usr/local/lib/riscv64-linux-gnu
cp -rf ./sysroot/lib/* /usr/local/lib/riscv64-linux-gnu/

echo "6. copy sysroot/crt/* --> /usr/lib/riscv64-linux-gnu/"
if [ -d /usr/lib/riscv64-linux-gnu ]; then
  rm -rf /usr/lib/riscv64-linux-gnu
fi
mkdir -p /usr/lib/riscv64-linux-gnu
cp -rf ./sysroot/crt/* /usr/lib/riscv64-linux-gnu/

echo "7. install success"

