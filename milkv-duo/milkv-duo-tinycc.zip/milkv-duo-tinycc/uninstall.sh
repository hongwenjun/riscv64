#!/bin/sh

if [ -d /usr/local/lib/tcc/ ]; then
  rm -rf /usr/local/lib/tcc/
fi

if [ -d /usr/local/include/tcc/ ]; then
  rm -rf /usr/local/include/tcc/
fi

if [ -f /usr/bin/tcc ];then
  rm /usr/bin/tcc
fi
if [ -f /usr/local/bin/tcc ];then
  rm /usr/local/bin/tcc
fi

if [ -d /usr/local/include/riscv64-linux-gnu ]; then
  rm -rf /usr/local/include/riscv64-linux-gnu
fi

if [ -d /usr/local/lib/riscv64-linux-gnu ]; then
  rm -rf /usr/local/lib/riscv64-linux-gnu
fi

if [ -d /usr/lib/riscv64-linux-gnu ]; then
  rm -rf /usr/lib/riscv64-linux-gnu
fi

echo "uninstall success"

