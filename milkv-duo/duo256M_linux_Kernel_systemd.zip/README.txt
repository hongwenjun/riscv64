﻿windows 打开 tf 卡
替换 内核文件，
就能从 duo 64m 的 linux镜像更新到 duo 256m
==================
windows open tf card
Replace the kernel file,

You can update the linux image from duo 64m to duo 256m